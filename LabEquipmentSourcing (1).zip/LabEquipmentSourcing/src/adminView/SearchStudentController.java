/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Admins;
import model.Students;
import presenter.StudentPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class SearchStudentController implements Initializable {

    @FXML
    private Button homeadmin_fx;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Text home_fx;
    @FXML
    private Button searchstudentdet_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private TableView<Students> studentdettable_fx;
    @FXML
    private RadioButton rbsrchbyid_fx;
    @FXML
    private RadioButton rbsrchbyname_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    @FXML
    private Button logout_fx;

    
    private StudentPresenter studentPresenter;
    @FXML
    private TableColumn<Students, Integer> id_column;
    @FXML
    private TableColumn<Students, String> name_column;
    @FXML
    private TableColumn<Students, String> phone_column;
    @FXML
    private TableColumn<Students, String> campus_column;
    @FXML
    private TableColumn<Students, String> username_column;
    @FXML
    private TableColumn<Students, String> address_column;
    @FXML
    private TableColumn<Students, String> email_column;
    @FXML
    private TextField search_fx;
    @FXML
    private Button fullStudentListBtn;
    @FXML
    private Button deleteStudentBtn;
    
    private Students selectedStudent;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        studentPresenter = new StudentPresenter();
        selectedStudent = new Students();
        
        List<Students> studentList = studentPresenter.getAllStudentList();
        getAllStudentList(studentList);
       
       
        ToggleGroup group = new ToggleGroup();
        rbsrchbyname_fx.setToggleGroup(group);
        rbsrchbyid_fx.setToggleGroup(group);
    }    

    @FXML
    private void onHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();        
    }

    @FXML
    private void onSearchButtonClicked(ActionEvent event) {
        if(rbsrchbyname_fx.isSelected()==true){
            String keyword = search_fx.getText();
            List<Students> searchedStudents = studentPresenter.findStudentsByName(keyword);
            getAllStudentList(searchedStudents);  
        }else if (rbsrchbyid_fx.isSelected()==true){
            String keyword = search_fx.getText();
            try{
                int id = Integer.parseInt(keyword);
                List<Students> searchedStudents = studentPresenter.findStudentsById(id);
                getAllStudentList(searchedStudents);
            }catch(NumberFormatException ex){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Invalid Input");
                alert.setHeaderText("Please enter a numeric value for Student ID.");
                alert.showAndWait();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No search type selected");
            alert.setHeaderText("Please select one search option first.");
            alert.showAndWait();
        }
    }
    
    private void getAllStudentList(List <Students> studentList){
        id_column.setCellValueFactory(new PropertyValueFactory<>("student_id"));
        name_column.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        phone_column.setCellValueFactory(new PropertyValueFactory<>("phone"));
        email_column.setCellValueFactory(new PropertyValueFactory<>("email"));
        address_column.setCellValueFactory(new PropertyValueFactory<>("address"));
        campus_column.setCellValueFactory(new PropertyValueFactory<>("campus"));
        username_column.setCellValueFactory(new PropertyValueFactory<>("username"));
        
        ObservableList<Students> studentsList = FXCollections.observableList(studentList);
        studentdettable_fx.setItems(studentsList);
        if (studentsList.isEmpty()) {
            studentdettable_fx.setPlaceholder(new Label("No records found!"));
        }
    }

    @FXML
    private void onFullStudentListBtnClicked(ActionEvent event) {
        List<Students> studentList = studentPresenter.getAllStudentList();
        getAllStudentList(studentList);
        
//        editDetailsbtn.setVisible(true);
//        saveChangesBtn.setVisible(false);
//        admindettable_fx.setEditable(false);
//        username_Column.setEditable(false);
    }

    @FXML
    private void onDeleteStudentBtnClicked(ActionEvent event) {
        int student_id = studentdettable_fx.getSelectionModel().getSelectedItem().getStudent_id();
        studentPresenter.deleteStudent(student_id);
        studentdettable_fx.getItems().removeAll(studentdettable_fx.getSelectionModel().getSelectedItem());
    }

}