/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.ActiveUser;
import model.Admins;
import presenter.AdminPresenter;
import presenter.ActiveUserPresenter;
import view.LoginController;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class AddAdminController implements Initializable {

    @FXML
    private TextArea addressreg_fx;
    @FXML
    private TextField adminNamereg_fx;
    @FXML
    private TextField mobilenumreg_fx;

    @FXML
    private ComboBox<String> campusChoiceBox;
    @FXML
    private TextField usernamereg_fx;
    @FXML
    private TextField passwordreg_fx;
    @FXML
    private TextField emailreg_fx;
    
    @FXML
    private Button studentregbutton_fx;
    
    private AdminPresenter adminPresenter;
    
    private ActiveUser activeUser;
    private LoginController lo;
    
    private ActiveUserPresenter activeUserPresenter;
    
    @FXML
    private Button homeadmin_fx1;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    
   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        adminPresenter = new AdminPresenter();
        activeUserPresenter = new ActiveUserPresenter();
       // lo = new LoginController();
        activeUser = new ActiveUser();
        campusChoiceBox.getItems().add("Sydney");     
        campusChoiceBox.getItems().add("Melbourne");     
        campusChoiceBox.getItems().add("Rockhampton");     
        campusChoiceBox.getItems().add("Perth"); 
    }    

    @FXML
    private void onRegisterNowButtonClicked(ActionEvent event) {
        
        String adminName = adminNamereg_fx.getText();
        String adminEmail = emailreg_fx.getText();
        String adminPhone = mobilenumreg_fx.getText();
        String adminUsername = usernamereg_fx.getText();
        String adminPassword = passwordreg_fx.getText();
        String adminAddress = addressreg_fx.getText();
        String adminCampus = campusChoiceBox.getValue();
        
        
       // ActiveUser activeUser = 
        List<ActiveUser> myUsername =  activeUserPresenter.getMyUsername();
        
        Admins admin = new Admins(adminName, adminEmail, adminPhone, adminUsername, adminPassword, adminAddress, adminCampus);
        boolean addNewAdmin = this.adminPresenter.registerAdmin(admin);
        
        if(addNewAdmin==true){
            Date dateNow = this.adminPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (myUsername.get(0).getUsername() + " " + dateNow +" - Added a new Admin named : "+ adminName);
            System.out.println("notification is : "+ notification);
            this.adminPresenter.writeToFile(notification);

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("New Admin Added");
            alert.setHeaderText("You have added a new Admin.");
            alert.showAndWait();
        }else{
            Date dateNow = this.adminPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (myUsername.get(0).getUsername() + " " + dateNow +" - Failed to add a new Admin named : "+ adminName);
            System.out.println(notification);
            this.adminPresenter.writeToFile(notification);
            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Failed to add a new Admin");
            alert.setHeaderText("Username/Email/Phone already exists.");
            alert.showAndWait();
        }
        
        
    }

    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();           
    }
    

    @FXML
    private void onAddEquipmentBtnClicked(ActionEvent event) throws IOException {
              Parent root = FXMLLoader.load(getClass().getResource("AddEquipment.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();   
    }


    
}
