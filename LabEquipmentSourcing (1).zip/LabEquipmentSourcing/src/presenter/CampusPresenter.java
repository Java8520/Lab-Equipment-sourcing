/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import model.Campuses;

/**
 *
 * @author Adarsha
 */
public class CampusPresenter {
        private CampusPersister campusPersister;
    
    public CampusPresenter() {
        this.campusPersister = new CampusPersister();
    }
    
    public boolean registerCampus(Campuses campus) {
        return campusPersister.registerCampus(campus);
    }

    public List<Campuses> getAllCampusList() {
        return campusPersister.getAllCampuses();
    }

    public List<Campuses> findCampusesByName(String keyword) {
        return campusPersister.findCampusesByName(keyword);
    }

    public List<Campuses> findCampusesById(int id) {
         return campusPersister.findCampusesById(id);
    }

    public String deleteCampus(int campus_id) {
        return campusPersister.deleteCampus(campus_id);
    }

    public Date getDateFromLocalDate(LocalDate date) {
        return campusPersister.getDateFromLocalDate(date);
    }

    public void writeToFile(String notification) {
        campusPersister.writeToFile(notification);
    }
    
}
