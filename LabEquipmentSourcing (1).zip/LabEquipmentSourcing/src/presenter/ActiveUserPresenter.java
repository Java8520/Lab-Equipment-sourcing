/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.util.List;
import model.ActiveUser;

/**
 *
 * @author Adarsha
 */
public class ActiveUserPresenter {
    private ActiveUserPersister activeUserPersister;

    public ActiveUserPresenter() {
        activeUserPersister = new ActiveUserPersister();
    }

    public boolean addActiveUser(ActiveUser activeUser) {
        return activeUserPersister.addActiveUser(activeUser);
    }

    public List<ActiveUser> getMyUsername() {
        return activeUserPersister.getMyUsername();
    }

    public void deleteActiveUser(String activeUsername) {
        activeUserPersister.deleteActiveUser(activeUsername);
    }
    
    
    
}
