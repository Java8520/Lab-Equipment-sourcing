/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import model.BorrowedEquipments;
import model.Equipments;

/**
 *
 * @author Adarsha
 */
public class EquipmentPresenter {
    
    private EquipmentPersister equipmentPersister;
    
    public EquipmentPresenter(){
        this.equipmentPersister = new EquipmentPersister();
        
        
    }
    
    

    public List<Equipments> getAllEquipmentList() {
        return equipmentPersister.getAllEquipmentList();
    }

    public boolean registerEquipment(Equipments equipment) {
        return equipmentPersister.registerEquipment(equipment);
    }

    public Date getDateFromLocalDate(LocalDate now) {
        return equipmentPersister.getDateFromLocalDate(now);
    }

    public void writeToFile(String notification) {
        equipmentPersister.writeToFile(notification);
    }

    public String deleteEquipment(int equipment_id) {
        return equipmentPersister.deleteEquipment(equipment_id);
    }

    public List<Equipments> findEquipmentsByName(String keyword) {
        return equipmentPersister.findEquipmentsByName(keyword);
    }

    public List<Equipments> findEquipmentsById(int id) {
        return equipmentPersister.findEquipmentsById(id);
    }

    public void addBorrowedEquipment(BorrowedEquipments equipments) {
        equipmentPersister.addBorrowedEquipment(equipments);
    }

    public List<Equipments> getAllEquipmentListForStudents() {
        return equipmentPersister.getAllEquipmentListForStudents();
    }
    
}
