/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import model.Students;

/**
 *
 * @author Adarsha
 */
public class StudentPresenter {
    
    private StudentPersister studentPersister;
    
    public StudentPresenter(){
        this.studentPersister = new StudentPersister();
    }

    public boolean registerStudent(Students student) {
        System.out.println("At the presenter");
        return studentPersister.registerStudent(student);
    }

    public Date getDateFromLocalDate(LocalDate date) {
        return studentPersister.getDateFromLocalDate(date);
    }

    public void writeToFile(String notification) {
        studentPersister.writeToFile(notification);
    }

    public List<Students> getAllStudentList() {
        return studentPersister.getAllStudentList();
    }

    public String deleteStudent(int student_id) {
        return studentPersister.deleteStudent(student_id);
    }

    public List<Students> findStudentsByName(String keyword) {
        return studentPersister.findStudentsByName(keyword);
    }

    public List<Students> findStudentsById(int id) {
        return studentPersister.findStudentsById(id);
    }

    public boolean isStudentExist(String username, String password) {
        return studentPersister.isStudentExist(username, password);
    }

    public boolean updateStudent(Students student) {
        return studentPersister.updateStudent(student);
    }
    
}
