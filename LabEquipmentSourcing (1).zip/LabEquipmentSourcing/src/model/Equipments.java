/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Adarsha
 */
public class Equipments {
    private int equipment_id;
    private String equipment_name;
    private String equipment_brand;
    private String equipment_type;
    private int availableQuantities;
    private String campus;

    public Equipments(String equipment_name, String equipment_brand, String equipment_type, int availableQuantities, String campus) {
        this.equipment_name = equipment_name;
        this.equipment_brand = equipment_brand;
        this.equipment_type = equipment_type;
        this.availableQuantities = availableQuantities;
        this.campus = campus;
    }

    public Equipments() {
       
    }

    public int getEquipment_id() {
        return equipment_id;
    }

    public void setEquipment_id(int equipment_id) {
        this.equipment_id = equipment_id;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public String getEquipment_brand() {
        return equipment_brand;
    }

    public void setEquipment_brand(String equipment_brand) {
        this.equipment_brand = equipment_brand;
    }

    public String getEquipment_type() {
        return equipment_type;
    }

    public void setEquipment_type(String equipment_type) {
        this.equipment_type = equipment_type;
    }

    public int getAvailableQuantities() {
        return availableQuantities;
    }

    public void setAvailableQuantities(int availableQuantities) {
        this.availableQuantities = availableQuantities;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    @Override
    public String toString() {
        return "Equipments{" + "equipment_id=" + equipment_id + ", equipment_name=" + equipment_name + ", equipment_brand=" + equipment_brand + ", equipment_type=" + equipment_type + ", availableQuantities=" + availableQuantities + ", campus=" + campus + '}';
    }
    
    
    
}
