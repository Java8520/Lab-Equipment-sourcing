/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Adarsha
 */
public class Students {
    private int student_id;
    private String StudentName;
    private String phone;
    private String campus;
    private String username;
    private String password;
    private String address;
    private String email;

    public Students() {
    }

    public Students(String StudentName, String phone, String campus, String username, String password, String address, String email) {
        this.StudentName = StudentName;
        this.phone = phone;
        this.campus = campus;
        this.username = username;
        this.password = password;
        this.address = address;
        this.email = email;
    }

    public String getStudentName() {
        return StudentName;
    }

    public void setStudentName(String StudentName) {
        this.StudentName = StudentName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    @Override
    public String toString() {
        return "Students{" + "student_id=" + student_id + ", StudentName=" + StudentName + ", phone=" + phone + ", campus=" + campus + ", username=" + username + ", password=" + password + ", address=" + address + ", email=" + email + '}';
    }
    
    
    
    
    
    
}
