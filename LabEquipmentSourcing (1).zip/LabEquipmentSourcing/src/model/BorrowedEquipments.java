/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Adarsha
 */
public class BorrowedEquipments {
    private int borrowID;
    private Equipments borrowedEquipments;
    private ActiveUser activeUser;
    private Date borrowDate;
    private Date returnDate;
    private String status;
    
    private int equipmentID;
    private String equipmentName;
    private String equipmentBrand;
    private String equipmentType;
    private String borrowerUsername;
    private Date returned_onDate;

    public BorrowedEquipments() {
    }

    public BorrowedEquipments(int borrowID, Equipments borrowedEquipments, ActiveUser activeUser, Date borrowDate, Date returnDate, String status, Date returned_onDate) {
        this.borrowID = borrowID;
        this.borrowedEquipments = borrowedEquipments;
        this.activeUser = activeUser;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.status = status;
        this.returned_onDate = returned_onDate;
    }
    
    

    public BorrowedEquipments(Equipments borrowedEquipments, ActiveUser activeUser, Date borrowDate, Date returnDate, String status) {
        this.borrowedEquipments = borrowedEquipments;
        this.activeUser = activeUser;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.status = status;
    }

    public BorrowedEquipments(Equipments eq, ActiveUser get, Date borrowDate, Date returnDate, String status, Date returnedDate) {
        this.borrowedEquipments = eq;
        this.activeUser = get;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.status = status;
        this.returned_onDate = returnedDate;
        
    }

//    public BorrowedEquipments(Equipments borrowedEquipments, Date borrowDate, Date returnDate, String status) {
//        this.borrowedEquipments = borrowedEquipments;
//        this.borrowDate = borrowDate;
//        this.returnDate = returnDate;
//    }

    public Equipments getBorrowedEquipments() {
        return borrowedEquipments;
    }

    public void setBorrowedEquipments(Equipments borrowedEquipments) {
        this.borrowedEquipments = borrowedEquipments;
    }

    public ActiveUser getActiveUser() {
        return activeUser;
    }

    public void setActiveUser(ActiveUser activeUser) {
        this.activeUser = activeUser;
    }



    public Date getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(Date borrowDate) {
        this.borrowDate = borrowDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public int getBorrowID() {
        return borrowID;
    }

    public void setBorrowID(int borrowID) {
        this.borrowID = borrowID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public int getEquipmentID(){
        return getBorrowedEquipments().getEquipment_id();
    }
    
    public String getEquipmentName(){
        return getBorrowedEquipments().getEquipment_name();
    }

    public String getEquipmentBrand() {
        return getBorrowedEquipments().getEquipment_brand();
    }

    public String getEquipmentType() {
        return getBorrowedEquipments().getEquipment_type();
    }

    public String getBorrowerUsername() {
        return getActiveUser().getUsername();
    }

    public Date getReturned_onDate() {
        return returned_onDate;
    }

    public void setReturned_onDate(Date returned_onDate) {
        this.returned_onDate = returned_onDate;
    }
    
    
    
    

    @Override
    public String toString() {
        return "BorrowedEquipments{" + "borrowID=" + borrowID + ", borrowedEquipments=" + borrowedEquipments + ", activeUser=" + activeUser + ", borrowDate=" + borrowDate + ", returnDate=" + returnDate + ", status=" + status + '}';
    }

    
    


    
    


}
