/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Adarsha
 */
public class Campuses {
    private String campusName;
    private String campusLocation;
    private String campusPhone;
    private String campusAddress;
    private int campus_id;

    public Campuses(String campusName, String campusLocation, String campusPhone, String campusAddress) {
        this.campusName = campusName;
        this.campusLocation = campusLocation;
        this.campusPhone = campusPhone;
        this.campusAddress = campusAddress;
    }
    
    public Campuses(){};

    public String getCampusName() {
        return campusName;
    }

    public void setCampusName(String campusName) {
        this.campusName = campusName;
    }

    public String getCampusLocation() {
        return campusLocation;
    }

    public void setCampusLocation(String campusLocation) {
        this.campusLocation = campusLocation;
    }

    public String getCampusPhone() {
        return campusPhone;
    }

    public void setCampusPhone(String campusPhone) {
        this.campusPhone = campusPhone;
    }

    public String getCampusAddress() {
        return campusAddress;
    }

    public void setCampusAddress(String campusAddress) {
        this.campusAddress = campusAddress;
    }

    public int getCampus_id() {
        return campus_id;
    }

    public void setCampus_id(int campusId) {
        this.campus_id = campusId;
    }
    
    
    
    

    @Override
    public String toString() {
        return "Campuses{" +"campusId="+campus_id+ ", campusName=" + campusName + ", campusLocation=" + campusLocation + ", campusPhone=" + campusPhone +", campusAddress=" +campusAddress+ '}';
    }
    
    
    
}
