/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Admins;
import model.Admins;
import presenter.ActiveUserPresenter;
import presenter.AdminPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class AdminProfileController implements Initializable {

    @FXML
    private TextArea addressreg_fx;
    @FXML
    private TextField adminNamereg_fx;
    @FXML
    private TextField emailreg_fx;
    @FXML
    private TextField mobilenumreg_fx;
    @FXML
    private ComboBox<String> campusChoiceBox;
    @FXML
    private TextField usernamereg_fx;
    @FXML
    private TextField passwordreg_fx;
    @FXML
    private Button homeadmin_fx1;
    @FXML
    private Button viewadmindetails_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Button addAdmin_fx;

    @FXML
    private Button notify_fx;
    
    private ActiveUserPresenter activeUserPresenter;
    private AdminPresenter adminPresenter;
    Admins admins;
    @FXML
    private Button updateBtn;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        activeUserPresenter = new ActiveUserPresenter();
        String username = activeUserPresenter.getMyUsername().get(0).getUsername();
        
        adminPresenter = new AdminPresenter();
        admins = new Admins();
        admins = adminPresenter.findAdminsByName(username).get(0);
        
        adminNamereg_fx.setText(admins.getAdminName());
        emailreg_fx.setText(admins.getAdminEmail());
        mobilenumreg_fx.setText(admins.getAdminPhone());
        usernamereg_fx.setText(admins.getAdminUsername());
        passwordreg_fx.setText(admins.getAdminPassword());
        addressreg_fx.setText(admins.getAdminAddress());
        
        campusChoiceBox.getItems().add("Sydney");     
        campusChoiceBox.getItems().add("Melbourne");     
        campusChoiceBox.getItems().add("Rockhampton");     
        campusChoiceBox.getItems().add("Perth"); 
        
        
    }    


    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }


    @FXML
    private void onUpdateButtonClicked(ActionEvent event) {
                String name = adminNamereg_fx.getText();
        String email = emailreg_fx.getText();
        String phone = mobilenumreg_fx.getText();
        String username = usernamereg_fx.getText();
        String password = passwordreg_fx.getText();
        String address = addressreg_fx.getText();
        String campus = campusChoiceBox.getValue();
        
        int myID = admins.getAdmin_id();
        
        Admins admin = new Admins (name, email, phone, username, password, address, campus);
        admin.setAdmin_id(myID);
        boolean updateAdmin = this.adminPresenter.updateAdmin(admin);
        
        if(updateAdmin==true){
            Date dateNow = this.adminPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (username + " " + dateNow + " updated his/her details.");
            System.out.println("notification is : "+ notification);
            this.adminPresenter.writeToFile(notification);

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Admin Details Updated");
            alert.setHeaderText("You have updated your details.");
            alert.showAndWait();
        }else{
            Date dateNow = this.adminPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (username + " " + dateNow +" - Failed to update the details.");
            System.out.println(notification);
            this.adminPresenter.writeToFile(notification);
            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Failed to Update.");
            alert.setHeaderText("Username/Email/Phone already exists.");
            alert.showAndWait();
        }
    }
    
}
