/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Admins;
import model.Equipments;
import presenter.EquipmentPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class AddEquipmentController implements Initializable {

    @FXML
    private TextField equipnamereg_fx;
    @FXML
    private Button equipregbutton_fx;
    @FXML
    private ChoiceBox<String> campusChoiceBox;
    @FXML
    private Button homeadmin_fx1;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    
    private EquipmentPresenter equipmentPresenter;
    @FXML
    private TextField equiptypereg_fx;
    @FXML
    private TextField equipbrandreg_fx1;
    @FXML
    private TextField equipquantitiesreg_fx;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        equipmentPresenter = new EquipmentPresenter();
        
        campusChoiceBox.getItems().add("Sydney");     
        campusChoiceBox.getItems().add("Melbourne");     
        campusChoiceBox.getItems().add("Rockhampton");     
        campusChoiceBox.getItems().add("Perth"); 
    }    

    @FXML
    private void onRegisterNowButtonClicked(ActionEvent event) {
        String equipmentName = equipnamereg_fx.getText();
        String equipmentBrand = equipbrandreg_fx1.getText();
        String equipmentType = equiptypereg_fx.getText();
        String equipmentAvailable = equipquantitiesreg_fx.getText();
        String equipmentCampus = campusChoiceBox.getValue();
        
        
       // ActiveUser activeUser = 
        String myUsername =  "admin1";// getActiveUser();
        //System.out.println("dateNow here :");
        System.out.println("my username is : "+myUsername);
        
        int equipmentAvailableQuantities = Integer.parseInt(equipmentAvailable);
        
        Equipments equipment = new Equipments(equipmentName, equipmentBrand,equipmentType, equipmentAvailableQuantities, equipmentCampus );
        boolean addNewEquipment = this.equipmentPresenter.registerEquipment(equipment);
        
        if(addNewEquipment==true){
            Date dateNow = this.equipmentPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (myUsername + " " + dateNow +" - Added a new Equipment named : "+ equipmentName);
            System.out.println("notification is : "+ notification);
            this.equipmentPresenter.writeToFile(notification);

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("New Equipment Added");
            alert.setHeaderText("You have added a new Equipment.");
            alert.showAndWait();
        }else{
            Date dateNow = this.equipmentPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (myUsername + " " + dateNow +" - Failed to add a new Equipment named : "+ equipmentName);
            System.out.println(notification);
            this.equipmentPresenter.writeToFile(notification);
            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Failed to add a new Equipment");
            alert.setHeaderText(" Equipment already exists.");
            alert.showAndWait();
        }
               
    }

    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
    
    
    
}
