/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Campuses;
import presenter.CampusPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class AddCampusController implements Initializable {

    @FXML
    private TextField nameofcampusreg_fx;
    @FXML
    private TextField locreg_fx;
    @FXML
    private TextArea campusaddreg_fx;
    @FXML
    private TextField phonereg_fx;
    
    @FXML
    private Button campusregbutton_fx;
    @FXML
    private Button homeadmin_fx;


    private CampusPresenter campusPresenter;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        campusPresenter = new CampusPresenter();
    }    

    @FXML
    private void onRegisterButtonClicked(ActionEvent event) {
        String campusName = nameofcampusreg_fx.getText();
        String campusLocation = locreg_fx.getText();
        String campusPhone = phonereg_fx.getText();
        String campusAddress = campusaddreg_fx.getText();
        
        String myUsername =  "admin1";// getActiveUser();
        
        
        Campuses campus = new Campuses(campusName, campusLocation, campusPhone, campusAddress);
        boolean addNewCampus = this.campusPresenter.registerCampus(campus);
        
        if(addNewCampus==true){
            Date dateNow = this.campusPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (myUsername + " " + dateNow +" - Added a new Campus named : "+ campusName);
            System.out.println("notification is : "+ notification);
            this.campusPresenter.writeToFile(notification);
            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("New Campus Added");
            alert.setHeaderText("You have added a new Campus.");
            alert.showAndWait();
        }else{
            Date dateNow = this.campusPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (myUsername + " " + dateNow +" - Failed to add a new Campus named : "+ campusName);
            System.out.println(notification);
            this.campusPresenter.writeToFile(notification);
            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Failed to add a new Campus");
            alert.setHeaderText("Already exists.");
            alert.showAndWait();
        }
    }

    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
    
}
