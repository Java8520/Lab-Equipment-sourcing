/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import model.Equipments;
import presenter.ActiveUserPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class EditEquipmentsController implements Initializable {

    @FXML
    private TextField equipnamereg_fx;
    @FXML
    private TextField equiptypereg_fx;
    @FXML
    private ChoiceBox<String> campusChoiceBox;
    @FXML
    private TextField equipbrandreg_fx1;
    @FXML
    private TextField equipquantitiesreg_fx;
    @FXML
    private Button homeadmin_fx1;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    @FXML
    private Button updateButton;
    
    private ActiveUserPresenter activeUserPresenter;
    private EquipmentDetailsController edc;
    private Equipments equipments;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        activeUserPresenter = new ActiveUserPresenter();
//        String username = activeUserPresenter.getMyUsername().get(0).getUsername();
//        
//        edc = new EquipmentDetailsController();
//        ArrayList eq = edc.getEqx1();
//        System.out.println("The array is :"+ eq.toString());
        
      //  equipments = new Equipments();
        //String eqName = equipments.getEquipment_name();
        
        //equipnamereg_fx.setText(eq[0]);
    }    


    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) {
    }

    @FXML
    private void onUpdateButtonClicked(ActionEvent event) {
    }
    
}
