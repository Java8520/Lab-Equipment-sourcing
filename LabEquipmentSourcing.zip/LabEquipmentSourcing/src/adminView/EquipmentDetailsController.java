/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Admins;
import model.Equipments;
import model.Students;
import presenter.EquipmentPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class EquipmentDetailsController implements Initializable {

    @FXML
    private Button homeadmin_fx;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Text home_fx;
    @FXML
    private TableView<Equipments> equipdettable_fx;
    @FXML
    private RadioButton rbequipsearchbyid_fx;
    @FXML
    private RadioButton rbequipsearchbyname_fx;
    @FXML
    private TextField equipsearch_fx;
    @FXML
    private Button searchequipdet_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    @FXML
    private Button logout_fx;
    @FXML
    private Button fullEquipmentListBtn;
    @FXML
    private Button deleteEquipmentBtn;
    
    private EquipmentPresenter equipmentPresenter;
    @FXML
    private TableColumn<Equipments, Integer> id_column;
    @FXML
    private TableColumn<Equipments, String> name_column;
    @FXML
    private TableColumn<Equipments, String> brand_column;
    @FXML
    private TableColumn<Equipments, String> type_column;
    @FXML
    private TableColumn<Equipments, String> availableQuantities_column;
    @FXML
    private TableColumn<Equipments, String> campus_column;
    @FXML
    private Button editBtn;
    
    ArrayList<String> eqx1;
    
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        equipmentPresenter = new EquipmentPresenter();
        
        List<Equipments> equipmentList = equipmentPresenter.getAllEquipmentList();
        getAllEquipmentList(equipmentList);
       
        
        ToggleGroup group = new ToggleGroup();
        rbequipsearchbyid_fx.setToggleGroup(group);
        rbequipsearchbyname_fx.setToggleGroup(group);
        
    }    

    @FXML
    private void onHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

    @FXML
    private void onSearchButtonClicked(ActionEvent event) {
        if(rbequipsearchbyname_fx.isSelected()==true){
            String keyword = equipsearch_fx.getText();
            System.out.println("Keyword is :"+ keyword);
            List<Equipments> searchedEquipments = equipmentPresenter.findEquipmentsByName(keyword);
            getAllEquipmentList(searchedEquipments);  
        }else if (rbequipsearchbyid_fx.isSelected()==true){
            String keyword = equipsearch_fx.getText();
            try{
                int id = Integer.parseInt(keyword);
                List<Equipments> searchedEquipments = equipmentPresenter.findEquipmentsById(id);
                getAllEquipmentList(searchedEquipments);
            }catch(NumberFormatException ex){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Invalid Input");
                alert.setHeaderText("Please enter a numeric value for Equipment ID.");
                alert.showAndWait();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No search type selected");
            alert.setHeaderText("Please select one search option first.");
            alert.showAndWait();
        }
    }

    @FXML
    private void onFullEquipmentListBtnClicked(ActionEvent event) {
        List<Equipments> equipmentList = equipmentPresenter.getAllEquipmentList();
        getAllEquipmentList(equipmentList);
    }

    @FXML
    private void onDeleteEquipmentBtnClicked(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Equipment.");
        alert.setHeaderText("Are you sure to delete the equipment?");
        Optional <ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK){
            int equipment_id = equipdettable_fx.getSelectionModel().getSelectedItem().getEquipment_id();
            equipmentPresenter.deleteEquipment(equipment_id);
            equipdettable_fx.getItems().removeAll(equipdettable_fx.getSelectionModel().getSelectedItem()); 
        }
        
        

        
        
    }

    private void getAllEquipmentList(List<Equipments> equipmentList) {
        id_column.setCellValueFactory(new PropertyValueFactory<>("equipment_id"));
        name_column.setCellValueFactory(new PropertyValueFactory<>("equipment_name"));
        brand_column.setCellValueFactory(new PropertyValueFactory<>("equipment_brand"));
        type_column.setCellValueFactory(new PropertyValueFactory<>("equipment_type"));
        availableQuantities_column.setCellValueFactory(new PropertyValueFactory<>("availableQuantities"));
        campus_column.setCellValueFactory(new PropertyValueFactory<>("campus"));
                
        ObservableList<Equipments> equipmentsList = FXCollections.observableList(equipmentList);
        equipdettable_fx.setItems(equipmentsList);
        if (equipmentsList.isEmpty()) {
            equipdettable_fx.setPlaceholder(new Label("No records found!"));
        }
    }

    @FXML
    private void onEditBtnClicked(ActionEvent event) throws IOException {
        int equipment_id = equipdettable_fx.getSelectionModel().getSelectedItem().getEquipment_id();
        Equipments eq = equipmentPresenter.findEquipmentsById(equipment_id).get(0);
        
        Equipments newEquip = new Equipments();
        newEquip.setEquipment_id(eq.getEquipment_id());
        newEquip.setEquipment_name(eq.getEquipment_name());
        newEquip.setEquipment_brand(eq.getEquipment_brand());
        newEquip.setEquipment_type(eq.getEquipment_type());
        newEquip.setAvailableQuantities(eq.getAvailableQuantities());
        newEquip.setCampus(eq.getCampus());
        
        
        int id = eq.getEquipment_id();
        String id1 = Integer.toString(id);
        
        String av = Integer.toString(eq.getAvailableQuantities());
        
//        eqx1.add(id1);
//        eqx1.add(eq.getEquipment_name());
//        eqx1.add(eq.getEquipment_brand());
//        eqx1.add(eq.getEquipment_type());
//        eqx1.add(av);
//        eqx1.add(eq.getCampus());
         //String [] eqx = {id1, eq.getEquipment_name(), eq.getEquipment_brand(), eq.getEquipment_type(), av, eq.getCampus()};
//        eqx[1].setEquipment_name(eq.getEquipment_name());
//        eqx[2].setEquipment_brand(eq.getEquipment_brand());
//        eqx[3].setEquipment_type(eq.getEquipment_type());
//        eqx[4].setAvailableQuantities(eq.getAvailableQuantities());
//        eqx[5].setCampus(eq.getCampus());
        
       // setEqx1(eqx);
        
      //  System.out.println("The array is : "+ eqx.toString());
        Parent root = FXMLLoader.load(getClass().getResource("EditEquipments.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
        
        
    }

    public ArrayList getEqx1() {
        return eqx1;
    }

    public void setEqx1(ArrayList eqx) {
        this.eqx1 = eqx;
    }
    
    
    
    
}
