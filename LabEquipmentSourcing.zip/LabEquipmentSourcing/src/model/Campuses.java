/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Adarsha
 */
public class Campuses {
    private String campusName;
    private String campusLocation;
    private String campusPhone;

    public Campuses(String campusName, String campusLocation, String campusPhone) {
        this.campusName = campusName;
        this.campusLocation = campusLocation;
        this.campusPhone = campusPhone;
    }

    public String getCampusName() {
        return campusName;
    }

    public void setCampusName(String campusName) {
        this.campusName = campusName;
    }

    public String getCampusLocation() {
        return campusLocation;
    }

    public void setCampusLocation(String campusLocation) {
        this.campusLocation = campusLocation;
    }

    public String getCampusPhone() {
        return campusPhone;
    }

    public void setCampusPhone(String campusPhone) {
        this.campusPhone = campusPhone;
    }

    @Override
    public String toString() {
        return "Campuses{" + "campusName=" + campusName + ", campusLocation=" + campusLocation + ", campusPhone=" + campusPhone + '}';
    }
    
    
    
}
