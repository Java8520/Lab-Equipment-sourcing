/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.studentView;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.ActiveUser;
import presenter.ActiveUserPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class NotificationStudentController implements Initializable {

    @FXML
    private Button homeadmin_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Text home_fx;
    @FXML
    private Button notify_fx;
    @FXML
    private TextArea notificationTextArea;
    private ActiveUser activeUser;
    private ActiveUserPresenter activeUserPresenter;
    @FXML
    private Button searchequip_fx;
    @FXML
    private Button booking_fx;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        activeUserPresenter = new ActiveUserPresenter();
        String username = activeUserPresenter.getMyUsername().get(0).getUsername();
        activeUser = new ActiveUser(username);
        System.out.println("activeUSer is "+ username);
        
        notificationTextArea.setEditable(false);
        List lines = displayNotifications();
        
        int n = lines.size();
        System.out.println("lines in file is: "+ n);
        for(int i=n;i>=1;i--){
            String line1 = lines.get(i-1).toString();
            String[] str = line1.split(" ");
            
            if(str[0].equals(username)){
                notificationTextArea.appendText(lines.get(i-1).toString()+"\n");
            } else {
            }
        } 
    }

    @FXML
    private void onHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("StudentDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }
    



    private List<String> displayNotifications() {
        List<String> lines = Collections.emptyList(); 
    
    try { 
        lines = Files.readAllLines(Paths.get("StudentLog.txt"), StandardCharsets.UTF_8);
        String username = lines.get(lines.size()-1);
        System.out.println("The user who made the changes is : "+ username);
    }catch (IOException e) { // TODO Auto-generated catch block
        e.printStackTrace(); 
    } 
    return lines;
    }

    @FXML
    private void onSettingsButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("StudentProfile.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }

    @FXML
    private void onNotificationButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("NotificationStudent.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }

    @FXML
    private void onSearchEquipmentButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SearchEquipment.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();         
    }

    @FXML
    private void onBookingButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("StudentHistory.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }
    
    
}
