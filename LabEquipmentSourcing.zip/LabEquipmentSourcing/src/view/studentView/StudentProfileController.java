/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.studentView;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Students;
import presenter.ActiveUserPresenter;
import presenter.StudentPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class StudentProfileController implements Initializable {

    @FXML
    private TextArea addressreg_fx;
    @FXML
    private TextField adminNamereg_fx;
    @FXML
    private TextField emailreg_fx;
    @FXML
    private TextField mobilenumreg_fx;
    @FXML
    private Button updatebutton_fx;
    @FXML
    private ComboBox<String> campusChoiceBox;
    @FXML
    private TextField usernamereg_fx;
    @FXML
    private TextField passwordreg_fx;
    @FXML
    private Button homeadmin_fx1;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button notify_fx;
    
    ActiveUserPresenter activeUserPresenter;
    Students students;
    StudentPresenter studentPresenter;
    @FXML
    private Button searchequip_fx;
    @FXML
    private Button booking_fx;
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        activeUserPresenter = new ActiveUserPresenter();
        String username = activeUserPresenter.getMyUsername().get(0).getUsername();
        
        studentPresenter = new StudentPresenter();
        students = new Students();
        students = studentPresenter.findStudentsByName(username).get(0);
        
        adminNamereg_fx.setText(students.getStudentName());
        emailreg_fx.setText(students.getEmail());
        mobilenumreg_fx.setText(students.getPhone());
        usernamereg_fx.setText(students.getUsername());
        passwordreg_fx.setText(students.getPassword());
        addressreg_fx.setText(students.getAddress());
        
        campusChoiceBox.getItems().add("Sydney");     
        campusChoiceBox.getItems().add("Melbourne");     
        campusChoiceBox.getItems().add("Rockhampton");     
        campusChoiceBox.getItems().add("Perth"); 
        
    }    

    @FXML
    private void onUpdateButtonClicked(ActionEvent event) {
        String name = adminNamereg_fx.getText();
        String email = emailreg_fx.getText();
        String phone = mobilenumreg_fx.getText();
        String username = usernamereg_fx.getText();
        String password = passwordreg_fx.getText();
        String address = addressreg_fx.getText();
        String campus = campusChoiceBox.getValue();
        
        int myID = students.getStudent_id();
        
        Students student = new Students (name, email, phone, username, password, address, campus);
        student.setStudent_id(myID);
        boolean updateStudent = this.studentPresenter.updateStudent(student);
        
        if(updateStudent==true){
            Date dateNow = this.studentPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (username + " " + dateNow + " updated his/her details.");
            System.out.println("notification is : "+ notification);
            this.studentPresenter.writeToFile(notification);

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Student Details Updated");
            alert.setHeaderText("You have updated your details.");
            alert.showAndWait();
        }else{
            Date dateNow = this.studentPresenter.getDateFromLocalDate(LocalDate.now());        
            String notification = (username + " " + dateNow +" - Failed to update the details.");
            System.out.println(notification);
            this.studentPresenter.writeToFile(notification);
            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Failed to Update.");
            alert.setHeaderText("Username/Email/Phone already exists.");
            alert.showAndWait();
        }
        
    }

    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("StudentDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }

@FXML
    private void onSettingsButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("StudentProfile.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }

    @FXML
    private void onNotificationButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("NotificationStudent.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }

    @FXML
    private void onSearchEquipmentButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("SearchEquipment.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();         
    }

    @FXML
    private void onBookingButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("StudentHistory.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }
    
}
