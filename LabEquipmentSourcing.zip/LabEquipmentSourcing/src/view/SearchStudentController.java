/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class SearchStudentController implements Initializable {

    @FXML
    private Button homeadmin_fx;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button adddelstudentID_fx;
    @FXML
    private Button addelequip_fx;
    @FXML
    private Button checkavail_fx;
    @FXML
    private Button acctset_fx;
    @FXML
    private Button adddelcampus_fx;
    @FXML
    private Text home_fx;
    @FXML
    private TextField studentname_fx;
    @FXML
    private TextField studentID_fx;
    @FXML
    private Button searchstudentdet_fx;
    @FXML
    private Button addstudentdet_fx;
    @FXML
    private Button delstudentdet_fx;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();        
    }

    @FXML
    private void onSearchButtonClicked(ActionEvent event) {
    }
    
}
