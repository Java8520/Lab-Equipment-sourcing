/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Admins;
import utility.DBConnection;

/**
 *
 * @author Adarsha
 */
public class AdminPersister {
    
    private Connection connection; // Connection object creation
    private PreparedStatement insertAdmin;
    
    public AdminPersister(){    
        try {
                this.connection = DBConnection.getConnection(); // database connection
                if (connection != null) {

                    insertAdmin = connection.prepareStatement("INSERT INTO admins (admin_name, username, password, email, contact, campus) "
                            + "VALUES(?, ?, ?, ?, ?, ?)");
                  

                }
            } catch (SQLException e) {
                System.out.println("Connection Failed!");
                System.out.println("SQLException : " + e.getMessage());
            }
    } 

    void registerAdmin(Admins admin) {
        try {
            insertAdmin.setString(1, admin.getAdminName());
            insertAdmin.setString(2, admin.getAdminUsername());
            insertAdmin.setString(3, admin.getAdminPassword());
            insertAdmin.setString(4, admin.getAdminEmail());
            insertAdmin.setString(5, admin.getAdminPhone());
            insertAdmin.setString(6, admin.getAdminCampus());
            insertAdmin.executeUpdate();  // execute the prepared statement insert
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
    }
    
}
