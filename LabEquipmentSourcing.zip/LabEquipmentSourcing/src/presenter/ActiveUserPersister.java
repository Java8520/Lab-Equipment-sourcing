/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ActiveUser;
import utility.DBConnection;

/**
 *
 * @author Adarsha
 */
public class ActiveUserPersister {

    private Connection connection;
    private PreparedStatement addNewActiveUser;
    private PreparedStatement getActiveUser;
    private PreparedStatement dropActiveUser;
    private DBConnection utility;
    
    public ActiveUserPersister() {
        utility = new DBConnection();
        try {
            this.connection = DBConnection.getConnection(); // database connection
            if (connection != null) {
                addNewActiveUser = connection.prepareStatement("INSERT INTO activeuser (username) "
                        + "VALUES(?)");
                getActiveUser = connection.prepareStatement("SELECT * FROM activeuser ORDER BY activeUser_id DESC LIMIT 1 ");
                dropActiveUser = connection.prepareStatement("DELETE FROM activeuser WHERE username = ? ");
            }
        } catch (SQLException e) {
            System.out.println("Connection Failed!");
            System.out.println("SQLException : " + e.getMessage());
        }

    }

    
    boolean addActiveUser(ActiveUser activeUser) {

        try {
            addNewActiveUser.setString(1, activeUser.getUsername());
            addNewActiveUser.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
            return false;
        }
    }

    List getMyUsername() {
        List<ActiveUser> activeUserList = new ArrayList<>();
        try{
            ResultSet myUsernameResult = getActiveUser.executeQuery();
            while (myUsernameResult.next()) {
                    int borrowId = myUsernameResult.getInt("activeUser_id");
                    String myUsername = myUsernameResult.getString("username");

                    ActiveUser newActiveUser = new ActiveUser(myUsername);
                    newActiveUser.setActiveUser_id(borrowId);
                    activeUserList.add(newActiveUser);
            }
            }catch(SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        return activeUserList;
    }

    void deleteActiveUser(String activeUsername) {
        try {

            dropActiveUser.setString(1, activeUsername);
            int activeUserResult = dropActiveUser.executeUpdate();

        } catch (SQLException e) {
            System.out.println("The activeUser cannot be deleted : " + e.getMessage());
        }
    }
        
}

