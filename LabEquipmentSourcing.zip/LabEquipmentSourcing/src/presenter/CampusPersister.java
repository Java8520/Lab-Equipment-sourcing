/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Campuses;
import utility.DBConnection;

/**
 *
 * @author Adarsha
 */
class CampusPersister {
    
    private Connection connection; // Connection object creation
    private PreparedStatement insertCampus;
    
    public CampusPersister(){    
        try {
                this.connection = DBConnection.getConnection(); // database connection
                if (connection != null) {

                    insertCampus = connection.prepareStatement("INSERT INTO campuses (campus_name, location, phone) "
                            + "VALUES(?, ?, ?)");                 

                }
            } catch (SQLException e) {
                System.out.println("Connection Failed!");
                System.out.println("SQLException : " + e.getMessage());
            }
    } 

    void registerCampus(Campuses campus) {
        try {
            insertCampus.setString(1, campus.getCampusName());
            insertCampus.setString(2, campus.getCampusLocation());
            insertCampus.setString(3, campus.getCampusPhone());
            insertCampus.executeUpdate();  // execute the prepared statement insert
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
    }
    
}
