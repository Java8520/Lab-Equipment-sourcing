/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import model.Admins;

/**
 *
 * @author Adarsha
 */
public class AdminPresenter {
    
    
    private AdminPersister adminPersister;
    
    public AdminPresenter() {
        this.adminPersister = new AdminPersister();
    }
    
    public boolean registerAdmin(Admins admin) {
        return adminPersister.registerAdmin(admin);
         
    }

    public List<Admins> getAllAdminList() {
        return adminPersister.getAllAdmins();
    }

    public String deleteAdmin(int admin_id) {
        return adminPersister.deleteAdmin(admin_id);
    }
    
    public boolean isAdminExist(String username, String password){
    return adminPersister.isAdminExist(username, password);
    }
    
    public void writeToFile(String notification){
        adminPersister.writeToFile(notification);
    }
    
    public Date getDateFromLocalDate(LocalDate date) {
        return adminPersister.getDateFromLocalDate(date);
    }

    public List<Admins> findAdminsById(int id) {
        return adminPersister.findAllAdminsById(id);
    }

    public List<Admins> findAdminsByName(String keyword) {
        return adminPersister.findAllAdminsByName(keyword);
    }
    
    public boolean updateAdmin(String column, String username, String adminName){
        return adminPersister.updateAdmin(column, username,adminName);
    }
}
