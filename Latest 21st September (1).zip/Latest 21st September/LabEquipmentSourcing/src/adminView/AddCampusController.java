/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Campuses;
import presenter.CampusPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class AddCampusController implements Initializable {

    @FXML
    private TextField nameofcampusreg_fx;
    @FXML
    private TextField locreg_fx;
    @FXML
    private TextArea campusaddreg_fx;
    @FXML
    private TextField phonereg_fx;
    
    @FXML
    private Button campusregbutton_fx;
    @FXML
    private Button homeadmin_fx;


    private CampusPresenter campusPresenter;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        campusPresenter = new CampusPresenter();
    }    

    @FXML
    private void onRegisterButtonClicked(ActionEvent event) {
        String campusName = nameofcampusreg_fx.getText();
        String campusLocation = locreg_fx.getText();
        String campusPhone = phonereg_fx.getText();
        String campusAddress = campusaddreg_fx.getText();
        
        Campuses campus = new Campuses(campusName, campusLocation, campusPhone, campusAddress);
        this.campusPresenter.registerCampus(campus);
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("New Campus Added");
        alert.setHeaderText("You have added a new Campus.");
        alert.showAndWait();
    }

    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
    
}
