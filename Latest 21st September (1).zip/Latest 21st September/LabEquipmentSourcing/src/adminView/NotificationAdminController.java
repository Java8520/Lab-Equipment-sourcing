/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adminView;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class NotificationAdminController implements Initializable {

    @FXML
    private Button homeadmin_fx;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Text home_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    @FXML
    private Button logout_fx;
    @FXML
    private TextArea notificationTextArea;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        notificationTextArea.setEditable(false);
        List lines = displayNotifications();
        int n = lines.size();
        System.out.println("lines in file is: "+ n);
        for(int i=n;i>=1;i--){
        notificationTextArea.appendText(lines.get(i-1).toString()+"\n");
    }
        
    }    

    @FXML
    private void onHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show(); 
    }

    @FXML
    private void onAddCampusesButtonClicked(ActionEvent event) {
    }

    @FXML
    private void onAddAdminButtonClicked(ActionEvent event) {
    }

    @FXML
    private void onCampusDetailsButtonClicked(ActionEvent event) {
    }

    @FXML
    private void onAdminDetailsButtonClicked(ActionEvent event) {
    }

    @FXML
    private void onLogoutButtonClicked(ActionEvent event) {
    }

    private List<String> displayNotifications() {
        

    List<String> lines = Collections.emptyList(); 
    try { 
        lines = Files.readAllLines(Paths.get("AdminLog.txt"), StandardCharsets.UTF_8);
    }catch (IOException e) { // TODO Auto-generated catch block
        e.printStackTrace(); 
    } 
    return lines;

    }
}
