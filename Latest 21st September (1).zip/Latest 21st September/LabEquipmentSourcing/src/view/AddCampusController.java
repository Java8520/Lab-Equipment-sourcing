/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class AddCampusController implements Initializable {

    @FXML
    private TextField nameofcampusreg_fx;
    @FXML
    private TextField locreg_fx;
    @FXML
    private TextField phonereg_fx;
    @FXML
    private TextArea campusaddreg_fx;
    @FXML
    private Button campusregbutton_fx;
    @FXML
    private Button homeadmin_fx1;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    @FXML
    private Button logout_fx;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void onRegisterButtonClicked(ActionEvent event) {
    }

    @FXML
    private void onBackToHomeButtonClicked(ActionEvent event) {
    }
    
}
