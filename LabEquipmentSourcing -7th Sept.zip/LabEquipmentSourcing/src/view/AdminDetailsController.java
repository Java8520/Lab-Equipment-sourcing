/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Admins;
import presenter.AdminPresenter;

/**
 * FXML Controller class
 *
 * @author Adarsha
 */
public class AdminDetailsController implements Initializable {

    @FXML
    private Button homeadmin_fx;
    @FXML
    private Button viewstudentdetails_fx;
    @FXML
    private Button addEquipment_fx;
    @FXML
    private Button equipmentSearch_fx;
    @FXML
    private Button Adddelcampus_fx;
    @FXML
    private Text home_fx;
    @FXML
    private TableView<Admins> admindettable_fx;
    @FXML
    private RadioButton rbadminsearchbyid_fx;
    @FXML
    private RadioButton rbadminsearchbyname_fx;
    @FXML
    private TextField adminsearchbyname_fx;
    @FXML
    private TextField adminsearchbyid_fx;
    @FXML
    private Button searchadmindet_fx;
    @FXML
    private Button addAdmin_fx;
    @FXML
    private Button addStudent_fx;
    @FXML
    private Button notify_fx;
    @FXML
    private Button logout_fx;
    @FXML
    private TableColumn<Admins, Integer> id_Column;
    @FXML
    private TableColumn<Admins, String> name_Column;
    @FXML
    private TableColumn<Admins, String> phone_Column;
    @FXML
    private TableColumn<Admins, String> email_Column;
    @FXML
    private TableColumn<Admins, String> address_Column;
    @FXML
    private TableColumn<Admins, String> campus_Column;
    @FXML
    private TableColumn<Admins, String> username_Column;
    
    private AdminPresenter adminPresenter;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        adminPresenter = new AdminPresenter();
       List<Admins> adminList = adminPresenter.getAllAdminList();
       getAllAdminList(adminList);
        
    }    

    @FXML
    private void onHomeButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDashboard.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();  
    }

    @FXML
    private void onAddCampusesButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminCampus.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();  
    }

    @FXML
    private void onSearchButtonClicked(ActionEvent event) {
    }

    @FXML
    private void onAddAdminButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddAdmin.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();          
    }

    @FXML
    private void onCampusDetailsButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("CampusDetails.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();          
    }

    @FXML
    private void onAdminDetailsButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminDetails.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();          
    }

    @FXML
    private void onLogoutButtonClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();          
    }

    private void getAllAdminList(List<Admins> adminList) {
                
        //id_Column.setCellValueFactory(new PropertyValueFactory<>("admin_id"));
        name_Column.setCellValueFactory(new PropertyValueFactory<>("adminName"));
        phone_Column.setCellValueFactory(new PropertyValueFactory<>("adminPhone"));
        email_Column.setCellValueFactory(new PropertyValueFactory<>("adminEmail"));
        address_Column.setCellValueFactory(new PropertyValueFactory<>("adminAddress"));
        campus_Column.setCellValueFactory(new PropertyValueFactory<>("adminCampus"));
        username_Column.setCellValueFactory(new PropertyValueFactory<>("adminUsername"));
        
        ObservableList<Admins> adminsList = FXCollections.observableList(adminList);
        admindettable_fx.setItems(adminsList);
        if (adminsList.isEmpty()) {
            admindettable_fx.setPlaceholder(new Label("No records found!"));
        }
    }
    
}