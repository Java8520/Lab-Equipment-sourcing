/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Campuses;
import utility.DBConnection;

/**
 *
 * @author Adarsha
 */
class CampusPersister {
    
    private Connection connection; // Connection object creation
    private PreparedStatement insertCampus;
    private PreparedStatement getAllCampuses;
    
    public CampusPersister(){    
        try {
                this.connection = DBConnection.getConnection(); // database connection
                if (connection != null) {

                    insertCampus = connection.prepareStatement("INSERT INTO campuses (campus_name, location, phone, address) "
                            + "VALUES(?, ?, ?, ?)");    
                    
                    getAllCampuses = connection.prepareStatement("SELECT * FROM campuses");

                }
            } catch (SQLException e) {
                System.out.println("Connection Failed!");
                System.out.println("SQLException : " + e.getMessage());
            }
    } 

    void registerCampus(Campuses campus) {
        try {
            insertCampus.setString(1, campus.getCampusName());
            insertCampus.setString(2, campus.getCampusLocation());
            insertCampus.setString(3, campus.getCampusPhone());
            insertCampus.setString(4, campus.getCampusAddress());
            insertCampus.executeUpdate();  // execute the prepared statement insert
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
    }

    List<Campuses> getAllCampuses() {
        List<Campuses> campusList = new ArrayList<>();
        try {
            ResultSet campusResult = getAllCampuses.executeQuery();

            System.out.println("Campus details reading from the database.");
            while (campusResult.next()) {
                int campusId = campusResult.getInt("campus_id");
                String campusName = campusResult.getString("campus_name");
                String campusLocation = campusResult.getString("location");
                String campusPhone = campusResult.getString("phone"); 
                String campusAddress = campusResult.getString("address");
                
                Campuses newCampus = new Campuses(campusName, campusLocation, campusPhone, campusAddress);
                newCampus.setCampus_id(campusId);
                System.out.println("New added campus is : "+newCampus);
                campusList.add(newCampus);
            }
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        System.out.println("Final campus list to be sent from persister is :"+ campusList);
        return campusList;
    }
    
}
