/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Admins;
import utility.DBConnection;

/**
 *
 * @author Adarsha
 */
public class AdminPersister {
    
    private Connection connection; // Connection object creation
    private PreparedStatement insertAdmin;
    private PreparedStatement getAllAdmins;
    
    public AdminPersister(){    
        try {
                this.connection = DBConnection.getConnection(); // database connection
                if (connection != null) {

                    insertAdmin = connection.prepareStatement("INSERT INTO admins (admin_name, username, password, email, phone, address, campus) "
                            + "VALUES(?, ?, ?, ?, ?, ?, ?)");
                    getAllAdmins = connection.prepareStatement("SELECT * FROM admins");
                  

                }
            } catch (SQLException e) {
                System.out.println("Connection Failed!");
                System.out.println("SQLException : " + e.getMessage());
            }
    } 

    void registerAdmin(Admins admin) {
        try {
            insertAdmin.setString(1, admin.getAdminName());
            insertAdmin.setString(2, admin.getAdminUsername());
            insertAdmin.setString(3, admin.getAdminPassword());
            insertAdmin.setString(4, admin.getAdminEmail());
            insertAdmin.setString(5, admin.getAdminPhone());
            insertAdmin.setString(6, admin.getAdminAddress());
            insertAdmin.setString(7, admin.getAdminCampus());
            insertAdmin.executeUpdate();  // execute the prepared statement insert
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
    }

    List<Admins> getAllAdmins() {
        List<Admins> adminList = new ArrayList<>();
        try {
            ResultSet adminResult = getAllAdmins.executeQuery();

            System.out.println("Admin details reading from the database.");
            while (adminResult.next()) {
                int adminId = adminResult.getInt("admin_id");
                String adminName = adminResult.getString("admin_name");
                String adminEmail = adminResult.getString("email");
                String adminPhone = adminResult.getString("phone");
                String adminUsername = adminResult.getString("username");  
                String adminPassword = adminResult.getString("password");  
                String adminAddress = adminResult.getString("address");
                String adminCampus = adminResult.getString("campus");   
                
                Admins newAdmin = new Admins(adminName, adminEmail, adminPhone, adminUsername, adminPassword, adminAddress, adminCampus);
                newAdmin.setAdmin_id(adminId);
                System.out.println("New added admin is : "+newAdmin);
                adminList.add(newAdmin);
            }
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        System.out.println("Final admins list to be sent from persister is :"+ adminList);
        return adminList;
    }
    
}
